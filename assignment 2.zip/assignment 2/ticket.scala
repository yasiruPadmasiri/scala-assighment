object ticket{


def main(args:Array[String])
{
var ticketPrice1=15;
var ticketPrice2=10;
var ticketPrice3=20;
var t15People =120;
var t10People=140;
var t20People=100;
var flim_cost=500;
var people_cost=3;
var p1=profit1(ticketPrice1,t15People,flim_cost,people_cost);
var p2=profit2(ticketPrice2,t10People,flim_cost,people_cost);
var p3=profit3(ticketPrice3,t20People,flim_cost,people_cost);
last(p1,p2,p3,ticketPrice1,ticketPrice2,ticketPrice3);

println("profit1 15 ticket is="+p1);
println("profit2 10 ticket is="+p2);
println("profit3 20 ticket is="+p3);



}

def profit1(t:Double,x:Double,f:Double,p:Double):Double={
  t*x-f-(p*x);
}



def profit2(t:Double,y:Double,f:Double,p:Double):Double={
  t*y-f-(p*y);
}



def profit3(t:Double,z:Double,f:Double,p:Double):Double={
   t*z-f-(p*z);
}

def last(p1:Double,p2:Double,p3:Double,ticketPrice1:Double,ticketPrice2:Double,ticketPrice3:Double):Unit={
if(p1>=p2)
{ println(" ");
  if(p1>=p3)
    { println(" ");
       println("best profit ticket is="+ ticketPrice1);
       println("best profit is="+p1);
     }
}

else 
     println(" ");
     {if(p2>=p3)
     { 
       println("best profit ticket is="+ ticketPrice2);
       println("best profit is="+p2);

       }
      else
        { println(" ");
          println("best profit ticket is="+ ticketPrice3);
         println("best profit is="+p3);
       }
}

}





}