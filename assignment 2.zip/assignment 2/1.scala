object sal{
def main(args:Array[String])
{

var normalHhourRrate=150;
var OTHoursRate=75;

def TheSalary(x:Double,y:Double):Double={
((x*40+y*20)*90)/100;

}

var Full_Salary=salary(normalHhourRrate,OTHoursRate);

println("salary is="+fullsalary);


}

}